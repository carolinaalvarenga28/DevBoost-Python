from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.core.window import Window
from kivy.graphics import Color, Rectangle, RoundedRectangle

# Ajustamos tamaño de la ventana
Window.size = (400, 600)

#colores tema oscuro personalizado
backgroundColor = (1, 1, 1, 1)
textColor = [1, 1, 1, 1]
MainButonColor = (60/255, 0/255, 98/255, 1)
SecondButonColor = [0.5, 0, 0.6, 1]

#Usuarios validos
usuarios = {
    "admin": "1234",
    "user": "abcd"
}
 
#Boton Personalizado
class BotonPersonalizado(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.font_size = 15
        self.background_normal = ''
        self.background_color = (0, 0, 0, 0)
        self.color = kwargs.get('color', textColor)
        with self.canvas.before:
            self.bg_color = Color(*kwargs.get('background_color', MainButonColor))
            self.rect = RoundedRectangle(size=self.size, pos=self.pos, radius=[20])
        self.bind(pos=self.update_rect, size=self.update_rect)
 
    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size

#Pantalla de bienvenida
class BienvenidaScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*backgroundColor)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.actualizar_rect, pos=self.actualizar_rect)
 
        layout = BoxLayout(orientation='vertical', spacing=20, padding=40)
        layout.add_widget(Image(source='logo2.png', size_hint=(1, 0.6), allow_stretch=True))
        layout.add_widget(Label(
            text="Bienvenido a Devboost",
            font_size=24,
            size_hint=(1, 0.1),
            color=textColor
        ))
 
        btn_ingresar = BotonPersonalizado(
            text="Ingresar",
            size_hint=(1, 0.1),
            font_size=16,
            background_color=SecondButonColor,
            color=textColor
        )
        btn_ingresar.bind(on_press=self.ir_a_login)
        layout.add_widget(btn_ingresar)
        self.add_widget(layout)
 
    def actualizar_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
 
    def ir_a_login(self, instance):
        self.manager.transition.direction = 'left'
        self.manager.current = 'seleccion'

#Pantalla de seleccion
class SeleccionScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*backgroundColor)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.actualizar_rect, pos=self.actualizar_rect)
 
        layout = BoxLayout(orientation='vertical', padding=40, spacing=20)
 
        logo_layout = BoxLayout(orientation='vertical', size_hint=(1, 0.4), spacing=5)
        logo_image = Image(source='rocket_icon.png', size_hint=(1, 0.6), allow_stretch=True)
        devboost_label = Label(text='Devboost', font_size=32, color=MainButonColor, bold=True, size_hint=(1, 0.2))
        logo_layout.add_widget(logo_image)
        logo_layout.add_widget(devboost_label)
        layout.add_widget(logo_layout)
 
        botones_layout = BoxLayout(orientation='vertical', spacing=15, size_hint=(1, 0.25))
        btn_login = BotonPersonalizado(text="Login", size_hint=(1, None), height=50, font_size=18, background_color=MainButonColor, color=textColor)
        btn_login.bind(on_press=self.ir_a_login)
        btn_register = BotonPersonalizado(text="Register", size_hint=(1, None), height=50, font_size=18, background_color=MainButonColor, color=textColor)
        btn_register.bind(on_press=self.ir_a_registro)
 
        botones_layout.add_widget(btn_login)
        botones_layout.add_widget(btn_register)
        layout.add_widget(botones_layout)
        layout.add_widget(Image(source='devboost_ilustracion.png', size_hint=(1, 0.35), allow_stretch=True))
        self.add_widget(layout)
 
    def actualizar_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
 
    def ir_a_login(self, instance):
        self.manager.transition.direction = 'left'
        self.manager.current = 'login'
 
    def ir_a_registro(self, instance):
        self.manager.transition.direction = 'left'
        self.manager.current = 'register'

#Pantalla de registro
class RegisterScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*backgroundColor)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.actualizar_rect, pos=self.actualizar_rect)
 
        layout = BoxLayout(orientation='vertical', padding=40, spacing=20)
        self.email = TextInput(hint_text="Email", multiline=False, size_hint=(1, None), height=45)
        self.username = TextInput(hint_text="Username", multiline=False, size_hint=(1, None), height=45)
        self.password = TextInput(hint_text="Password", multiline=False, password=True, size_hint=(1, None), height=45)
 
        btn_register = BotonPersonalizado(text="Registrar", size_hint=(1, None), height=45)
        btn_register.bind(on_press=self.registrar_usuario)
 
        layout.add_widget(Label(text="Registro", font_size=24, color=MainButonColor))
        layout.add_widget(self.email)
        layout.add_widget(self.username)
        layout.add_widget(self.password)
        layout.add_widget(btn_register)
 
        volver = Button(text="Volver", size_hint=(1, None), height=40)
        volver.bind(on_press=self.volver)
        layout.add_widget(volver)
        self.add_widget(layout)
 
    def actualizar_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
 
    def registrar_usuario(self, instance):
        email = self.email.text.strip()
        user = self.username.text.strip()
        pwd = self.password.text.strip()
        if email and user and pwd:
            if user in usuarios:
                Popup(title="Error", content=Label(text="El usuario ya existe.", color=textColor), size_hint=(0.6, 0.3)).open()
            else:
                usuarios[user] = pwd
                Popup(title="¡Éxito!", content=Label(text="Usuario registrado correctamente.", color=textColor), size_hint=(0.6, 0.3)).open()
                self.email.text = ''
                self.username.text = ''
                self.password.text = ''
        else:
            Popup(title="Error", content=Label(text="Completa todos los campos.", color=textColor), size_hint=(0.6, 0.3)).open()
 
    def volver(self, instance):
        self.manager.transition.direction = 'right'
        self.manager.current = 'seleccion'

#Pantalla de login
class LoginScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        with self.canvas.before:
            Color(*backgroundColor)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self.actualizar_rect, pos=self.actualizar_rect)
 
        layout = BoxLayout(orientation='vertical', padding=40, spacing=20)
        self.email = TextInput(hint_text="Email", multiline=False, size_hint=(1, None), height=45)
        self.username = TextInput(hint_text="Username", multiline=False, size_hint=(1, None), height=45)
        self.password = TextInput(hint_text="Password", multiline=False, password=True, size_hint=(1, None), height=45)
 
        btn_login = BotonPersonalizado(text="Iniciar sesión", size_hint=(1, None), height=45)
        btn_login.bind(on_press=self.iniciar_sesion)
 
        layout.add_widget(Label(text="Iniciar Sesión", font_size=24, color=MainButonColor))
        layout.add_widget(self.email)
        layout.add_widget(self.username)
        layout.add_widget(self.password)
        layout.add_widget(btn_login)
 
        volver = Button(text="Volver", size_hint=(1, None), height=40)
        volver.bind(on_press=self.volver)
        layout.add_widget(volver)
 
        self.add_widget(layout)
 
    def actualizar_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
 
    def iniciar_sesion(self, instance):
        email = self.email.text.strip()
        user = self.username.text.strip()
        pwd = self.password.text.strip()
        if email and user and pwd:
            if user in usuarios and usuarios[user] == pwd:
                self.manager.get_screen('usuario').saludo_label.text = f"[b]¡Hola, {user}![/b]"
                self.manager.transition.direction = 'left'
                self.manager.current = 'usuario'
            else:
                Popup(title="Error", content=Label(text="Usuario o contraseña incorrectos.", color=textColor), size_hint=(0.6, 0.3)).open()
        else:
            Popup(title="Error", content=Label(text="Completa todos los campos.", color=textColor), size_hint=(0.6, 0.3)).open()
 
    def volver(self, instance):
        self.manager.transition.direction = 'right'
        self.manager.current = 'seleccion'

#Pantalla de usuario
class UsuarioScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=40, spacing=20)
        self.saludo_label = Label(text="", font_size=24, markup=True, color=[0.2, 0.2, 0.2, 1])
        layout.add_widget(self.saludo_label)
        layout.add_widget(Label(text="Aquí verás tus datos personales", font_size=16, color=[0.2, 0.2, 0.2, 1]))
 
        cerrar_btn = Button(text="Cerrar sesión", size_hint_y=0.15, font_size=18, background_color=[0.6, 0.3, 0.8, 1], color=[1, 1, 1, 1])
        cerrar_btn.bind(on_press=self.cerrar_sesion)
        layout.add_widget(cerrar_btn)
        self.add_widget(layout)
 
    def cerrar_sesion(self, instance):
        self.manager.current = 'bienvenida'
 
class MyApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(BienvenidaScreen(name='bienvenida'))
        sm.add_widget(SeleccionScreen(name='seleccion'))
        sm.add_widget(LoginScreen(name='login'))
        sm.add_widget(RegisterScreen(name='register'))
        sm.add_widget(UsuarioScreen(name='usuario'))
        return sm
 
if __name__ == '__main__':
    MyApp().run()
 
 